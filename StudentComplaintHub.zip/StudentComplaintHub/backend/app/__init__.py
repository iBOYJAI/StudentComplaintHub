# Student Complaint & Resolution Hub
__version__ = "1.0.0"
